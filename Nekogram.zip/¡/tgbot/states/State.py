from tgbot.states.MenuState import Menu
from tgbot.states.AdminState import Admin


class State:
	menu = Menu
	admin = Admin